package br.com.caiosalgado.nubank.test.models;

public class AccountOperation {

    private AccountInput account;

    public AccountInput getAccount() {
        return account;
    }

    public void setAccount(AccountInput account) {
        this.account = account;
    }
}
